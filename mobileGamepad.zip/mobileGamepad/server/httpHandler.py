from BaseHTTPServer import BaseHTTPRequestHandler
import re

class HttpHandler(BaseHTTPRequestHandler):
	def do_GET(self):
		h = self.__parse()

		#TODO: check only if mobile, otherwise assume desktop
		#TODO: create dictionary, with key stating if client is desktop or not -> isMobile: true
		if self.path == '/':
			if self.__is_mobile(h['User-Agent']):
				self.__open_file('../client/gamepad.html')
			elif self.__is_desktop(h['User-Agent']):
				self.__open_file('../client/game.html')
			else:
				self.send_error(404, 'Device not supported')
		elif self.path == '/server/socketServer':
			print('hey we got here')
			self.__open_file('../server/socketServer.py');
		else:
			#add appropriate path prefix
			path = '../client/' + self.path
			self.__open_file(path)
		return

	#parse http headers and put keys and values into a dictionary
	def __parse(self):
		headers = str(self.headers)
		header_dict = dict(re.findall(r"(?P<name>.*?): (?P<value>.*?)\r\n", headers))
		return header_dict

	#returns true if the device is mobile, false otherwise
	def __is_mobile(self, str):
		return True if ((str.count('Android') > 0) | (str.count('iPad') > 0)) else False

	#returns true if the debice is a desktop, false otherwise
	def __is_desktop(self, str):
		return True if str.count('Linux') > 0 else False

	#open the html template file
	def __open_file(self, path):
		try:
			file = open(path, 'r')
			self.wfile.write(file.read())
			file.close()
		except IOError:
			self.send_error(404, 'File not found')

