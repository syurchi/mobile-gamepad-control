import asyncore
from clients import Clients

class SocketHandler(asyncore.dispatcher):
	def __init(self, socket):
		self.clients = Clients()
		asyncore.dispatcher.__init__(self, socket);

	#send data to desktop client
	def __send_to_desktop(self, data):
		clientList = self.clients.get()
		
		#for our purpose there should only be two clients, one desktop, one mobile (for now)
		for c in clientList:
			if c is not self:
				c.send(data)				

		#create a new socket connection with desktop
		print 'Sending data to desktop client'

	#TODO: not functional
	#handle a read() call
	def handle_read(self):
		print self
		print 'do we get to read'
		data = self.recv(8192)
		if data:
			self.send(data)
			# self.__send_to_desktop(data)
			# print data